PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'reader' CHECK(role IN ('reader','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS stories (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  author_name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Fiction',
  summary TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','published','rejected')),
  submitted_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  published_at TEXT
);

CREATE TABLE IF NOT EXISTS favorites (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  story_id TEXT NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(user_id, story_id)
);

CREATE INDEX IF NOT EXISTS idx_stories_status_published ON stories(status, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_stories_category ON stories(category);
CREATE INDEX IF NOT EXISTS idx_favorites_user ON favorites(user_id);

INSERT OR IGNORE INTO stories
(id,title,author_name,category,summary,content,status,published_at)
VALUES
('sample-moonlit-library','The Moonlit Library','Story Haven Editors','Fantasy','A mysterious library appears only when the moon is high.','The old library appeared at midnight, between the bakery and the little shop that sold broken clocks.\n\nMara had passed that empty space a thousand times. Tonight, warm gold light spilled beneath a carved oak door.\n\nInside, every book whispered a different beginning. One small volume glowed beneath the window, its title written in silver: The Story You Have Not Lived Yet.\n\nMara opened it—and heard footsteps on the stairs above.','published',CURRENT_TIMESTAMP),
('sample-starry-letters','Letters to the Stars','Ink & Ivy','Romance','Two strangers leave letters in the same secondhand bookshop.','The first letter was tucked into a poetry collection, folded into a neat square.\n\nIf you are reading this, write back. Tell me one thing you have never told anyone.\n\nBy Thursday, a reply waited between the pages. By Sunday, the letters had become a map of two lonely hearts finding their way home.','published',CURRENT_TIMESTAMP),
('sample-fanfic','A Different Ending','Willow Quill','Fanfiction','A fan-created alternate ending, offered as a sample category entry.','This sample demonstrates the Fanfiction category. Replace it with your own original or properly authorized fan-created work, and respect the rights and policies that apply to the characters and worlds you write about.','published',CURRENT_TIMESTAMP);
