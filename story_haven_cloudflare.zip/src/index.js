const COOKIE = "sh_session";
const enc = new TextEncoder();
const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status, headers: {"content-type":"application/json; charset=utf-8", "cache-control":"no-store", ...headers}});
const html = (body, status=200, headers={}) => new Response(body, {status, headers: {"content-type":"text/html; charset=utf-8", ...headers}});
const uid = () => crypto.randomUUID();
const b64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
const unb64 = (s) => Uint8Array.from(atob(s.replaceAll("-","+").replaceAll("_","/")), c => c.charCodeAt(0));
async function digestPassword(password, salt) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  return b64(await crypto.subtle.deriveBits({name:"PBKDF2", salt:enc.encode(salt), iterations:210000, hash:"SHA-256"}, key, 256));
}
async function sign(value, secret) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), {name:"HMAC", hash:"SHA-256"}, false, ["sign"]);
  return b64(await crypto.subtle.sign("HMAC", key, enc.encode(value)));
}
async function makeSession(user, secret) {
  const payload = b64(enc.encode(JSON.stringify({id:user.id, email:user.email, role:user.role, exp:Date.now()+7*86400000})));
  return payload + "." + await sign(payload, secret);
}
async function getUser(request, env) {
  const raw = (request.headers.get("Cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="))?.slice(COOKIE.length+1);
  if (!raw || !env.SESSION_SECRET) return null;
  const [payload, sig] = raw.split(".");
  if (!payload || !sig || await sign(payload, env.SESSION_SECRET) !== sig) return null;
  try {
    const session = JSON.parse(new TextDecoder().decode(unb64(payload)));
    if (session.exp < Date.now()) return null;
    return await env.DB.prepare("SELECT id,email,display_name,role FROM users WHERE id=?").bind(session.id).first();
  } catch { return null; }
}
const cookie = (value, maxAge=604800) => `${COOKIE}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`;
const safeUser = u => ({id:u.id,email:u.email,display_name:u.display_name,role:u.role});
function cleanText(v, max=10000) { return typeof v === "string" ? v.trim().slice(0,max) : ""; }
function sameOrigin(request) {
  const origin = request.headers.get("Origin");
  return !origin || origin === new URL(request.url).origin;
}
async function body(request) { try { return await request.json(); } catch { return {}; } }
export default {
 async fetch(request, env) {
  const url = new URL(request.url), path = url.pathname;
  if (request.method === "OPTIONS") return new Response(null,{status:204,headers:{"Access-Control-Allow-Origin":url.origin,"Access-Control-Allow-Credentials":"true","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"GET,POST,DELETE,OPTIONS","Vary":"Origin"}});
  if (path.startsWith("/api/") && !sameOrigin(request)) return json({error:"Cross-origin request blocked"},403);
  try {
   if (path === "/api/me" && request.method === "GET") {
    const user=await getUser(request,env); return json({user:user?safeUser(user):null});
   }
   if (path === "/api/register" && request.method === "POST") {
    const b=await body(request), email=cleanText(b.email,254).toLowerCase(), name=cleanText(b.name,60), password=typeof b.password==="string"?b.password:"";
    if (!email.includes("@") || !name || password.length<10 || password.length>200) return json({error:"Enter a valid email, a display name, and a password of at least 10 characters."},400);
    if (!env.SESSION_SECRET || !env.ADMIN_EMAIL) return json({error:"Site setup is incomplete. Ask the site owner to configure secrets."},503);
    const id=uid(), salt=b64(crypto.getRandomValues(new Uint8Array(16))), hash=await digestPassword(password,salt);
    const role=email===env.ADMIN_EMAIL.toLowerCase()?"admin":"reader";
    try { await env.DB.prepare("INSERT INTO users(id,email,display_name,password_hash,password_salt,role) VALUES(?,?,?,?,?,?)").bind(id,email,name,hash,salt,role).run(); }
    catch { return json({error:"That email may already be registered."},409); }
    const user={id,email,display_name:name,role}, token=await makeSession(user,env.SESSION_SECRET);
    return json({user:safeUser(user)},201,{"Set-Cookie":cookie(token)});
   }
   if (path === "/api/login" && request.method === "POST") {
    const b=await body(request), email=cleanText(b.email,254).toLowerCase(), password=typeof b.password==="string"?b.password:"";
    const u=await env.DB.prepare("SELECT * FROM users WHERE email=?").bind(email).first();
    if (!u || await digestPassword(password,u.password_salt)!==u.password_hash) return json({error:"Email or password is incorrect."},401);
    const token=await makeSession(u,env.SESSION_SECRET);
    return json({user:safeUser(u)},200,{"Set-Cookie":cookie(token)});
   }
   if (path === "/api/logout" && request.method === "POST") return json({ok:true},200,{"Set-Cookie":cookie("",0)});
   if (path === "/api/stories" && request.method === "GET") {
    const category=cleanText(url.searchParams.get("category"),40), search=cleanText(url.searchParams.get("q"),100);
    let sql="SELECT id,title,author_name,category,summary,created_at,published_at FROM stories WHERE status='published'", args=[];
    if (category && category!=="All") {sql+=" AND category=?";args.push(category);}
    if (search) {sql+=" AND (title LIKE ? OR author_name LIKE ? OR summary LIKE ?)";args.push(`%${search}%`,`%${search}%`,`%${search}%`);}
    sql+=" ORDER BY COALESCE(published_at,created_at) DESC LIMIT 100";
    const {results}=await env.DB.prepare(sql).bind(...args).all(); return json({stories:results});
   }
   if (path.startsWith("/api/stories/") && request.method==="GET") {
    const id=decodeURIComponent(path.slice("/api/stories/".length));
    const story=await env.DB.prepare("SELECT id,title,author_name,category,summary,content,published_at FROM stories WHERE id=? AND status='published'").bind(id).first();
    return story?json({story}):json({error:"Story not found"},404);
   }
   if (path === "/api/submit" && request.method === "POST") {
    const user=await getUser(request,env); if(!user) return json({error:"Sign in to submit a story."},401);
    const b=await body(request), title=cleanText(b.title,160), category=cleanText(b.category,40), summary=cleanText(b.summary,1000), content=cleanText(b.content,100000);
    if(!title||!content||!["Fiction","Fantasy","Romance","Mystery","Sci-Fi","Horror","Fanfiction","Poetry","Other"].includes(category)) return json({error:"Please provide a title, story text, and a valid category."},400);
    await env.DB.prepare("INSERT INTO stories(id,title,author_name,category,summary,content,status,submitted_by) VALUES(?,?,?,?,?,?,?,?)").bind(uid(),title,user.display_name,category,summary,content,"pending",user.id).run();
    return json({ok:true,message:"Submitted for review. It will appear publicly after approval."},201);
   }
   if (path === "/api/favorites" && request.method==="GET") {
    const user=await getUser(request,env); if(!user)return json({error:"Sign in required"},401);
    const {results}=await env.DB.prepare("SELECT s.id,s.title,s.author_name,s.category,s.summary FROM favorites f JOIN stories s ON s.id=f.story_id WHERE f.user_id=? AND s.status='published' ORDER BY f.created_at DESC").bind(user.id).all();
    return json({stories:results});
   }
   if (path.startsWith("/api/favorites/") && request.method==="POST") {
    const user=await getUser(request,env); if(!user)return json({error:"Sign in required"},401);
    const id=decodeURIComponent(path.slice("/api/favorites/".length));
    const exists=await env.DB.prepare("SELECT id FROM stories WHERE id=? AND status='published'").bind(id).first();
    if(!exists)return json({error:"Story not found"},404);
    await env.DB.prepare("INSERT OR IGNORE INTO favorites(user_id,story_id) VALUES(?,?)").bind(user.id,id).run(); return json({ok:true});
   }
   if (path.startsWith("/api/favorites/") && request.method==="DELETE") {
    const user=await getUser(request,env); if(!user)return json({error:"Sign in required"},401);
    await env.DB.prepare("DELETE FROM favorites WHERE user_id=? AND story_id=?").bind(user.id,decodeURIComponent(path.slice("/api/favorites/".length))).run(); return json({ok:true});
   }
   if (path==="/api/admin/submissions" && request.method==="GET") {
    const user=await getUser(request,env); if(!user||user.role!=="admin")return json({error:"Admin access required"},403);
    const {results}=await env.DB.prepare("SELECT id,title,author_name,category,summary,created_at FROM stories WHERE status='pending' ORDER BY created_at ASC").all(); return json({stories:results});
   }
   if (path.startsWith("/api/admin/submissions/") && request.method==="POST") {
    const user=await getUser(request,env); if(!user||user.role!=="admin")return json({error:"Admin access required"},403);
    const id=decodeURIComponent(path.slice("/api/admin/submissions/".length)), b=await body(request), action=b.action;
    if(!["approve","reject"].includes(action))return json({error:"Invalid moderation action"},400);
    await env.DB.prepare("UPDATE stories SET status=?, published_at=CASE WHEN ?='published' THEN CURRENT_TIMESTAMP ELSE published_at END WHERE id=? AND status='pending'").bind(action==="approve"?"published":"rejected",action==="approve"?"published":"rejected",id).run();
    return json({ok:true});
   }
   if(path.startsWith("/api/")) return json({error:"Not found"},404);
   return env.ASSETS.fetch(request);
  } catch (e) {
   return json({error:"Something went wrong. Please try again."},500);
  }
 }
};
