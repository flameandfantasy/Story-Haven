# Story Haven — Cloudflare edition

A book-themed, free-to-read story site starter for Cloudflare Workers + D1.

## Included
- Responsive bookish homepage and story reader
- Fiction and Fanfiction categories
- Free story listings and search
- Reader sign-up / sign-in using salted PBKDF2 password hashes and signed session cookies
- Favorites for signed-in readers
- Writer submissions held for owner approval
- Admin review/publish workflow
- Ad placement placeholders (not live ad-network integration)
- D1 schema and Cloudflare deployment configuration

## Before launch
This is a deployable starter, not a deployed site. You must create the Cloudflare resources and set secrets in your own account. Add a real email verification/password reset flow, moderation/reporting, privacy policy, terms, and an ad-network approval before opening to the public. Do not use the demo admin setup in production.

## Deploy (computer recommended)
1. Install current Node.js from https://nodejs.org/
2. Unzip this folder.
3. Open a terminal in this folder and run:
   ```bash
   npm install
   npx wrangler login
   npx wrangler d1 create story-haven-db
   ```
4. Copy the `database_id` returned by Cloudflare into `wrangler.jsonc` where it says `REPLACE_WITH_D1_DATABASE_ID`.
5. Create tables:
   ```bash
   npx wrangler d1 execute story-haven-db --remote --file=./migrations/0001_init.sql
   ```
6. Set secrets:
   ```bash
   npx wrangler secret put SESSION_SECRET
   npx wrangler secret put ADMIN_EMAIL
   ```
   `SESSION_SECRET` should be a long random secret (at least 32 characters). `ADMIN_EMAIL` is the email address that will receive the admin role on registration. Register that email first after deployment; keep it private.
7. Deploy:
   ```bash
   npm run deploy
   ```
8. Open the `workers.dev` URL shown by Wrangler.

## Cloudflare dashboard route
Cloudflare Dashboard → Workers & Pages → Create → Workers → Connect to Git (if you put this project in GitHub), or deploy with Wrangler as above. D1 setup and bindings are documented at https://developers.cloudflare.com/d1/get-started/

## Notes
- First registered account matching `ADMIN_EMAIL` receives admin role. Keep that email address private and set the secret before registering.
- Passwords are hashed; session cookies are HttpOnly, Secure, SameSite=Lax.
- For a real public launch, add email verification and password recovery, and test all flows.
- Ads are clearly marked placeholders. Add your approved network's code only after its approval and policy review.
